import 'package:flutter/material.dart';
import '../services/voo_service.dart';

class VooProvider extends ChangeNotifier {
  final VooService _service = VooService();

  List<Voo> _voos = [];
  bool _carregando = false;
  String? _erro;

  String aeroporto = 'SBGR';
  String tipo = 'todos';

  List<Voo> get voos => _voos;
  bool get carregando => _carregando;
  String? get erro => _erro;

  Future<void> buscarVoos() async {
    _carregando = true;
    _erro = null;
    notifyListeners();

    try {
      final resultado = await _service.buscarVoos(
        aeroporto: aeroporto,
        tipo: tipo,
      );
      _voos = resultado.voos;
    } catch (e) {
      _erro = e.toString().replaceFirst('Exception: ', '');
      _voos = [];
    }

    _carregando = false;
    notifyListeners();
  }

  void mudarAeroporto(String novoAeroporto) {
    aeroporto = novoAeroporto.trim().toUpperCase();
    buscarVoos();
  }

  void mudarTipo(String novoTipo) {
    tipo = novoTipo;
    buscarVoos();
  }
}
