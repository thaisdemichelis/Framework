import 'dart:convert';
import 'package:http/http.dart' as http;

class Voo {
  final String categoria; 
  final String identificacao;
  final String? tipoAeronave;
  final String? local; 
  final String? partida;
  final String? chegada;

  Voo({
    required this.categoria,
    required this.identificacao,
    this.tipoAeronave,
    this.local,
    this.partida,
    this.chegada,
  });

  factory Voo.fromJson(Map<String, dynamic> json) {
    return Voo(
      categoria: json['categoria'] ?? '',
      identificacao: json['identificacao'] ?? '',
      tipoAeronave: json['tipo_aeronave'],
      local: json['local'],
      partida: json['partida'],
      chegada: json['chegada'],
    );
  }
}


class ResultadoVoos {
  final String aeroporto;
  final String tipoBusca;
  final int total;
  final List<Voo> voos;

  ResultadoVoos({
    required this.aeroporto,
    required this.tipoBusca,
    required this.total,
    required this.voos,
  });

  factory ResultadoVoos.fromJson(Map<String, dynamic> json) {
    final listaVoos = (json['voos'] as List<dynamic>? ?? [])
        .map((item) => Voo.fromJson(item as Map<String, dynamic>))
        .toList();

    return ResultadoVoos(
      aeroporto: json['aeroporto'] ?? '',
      tipoBusca: json['tipo_busca'] ?? '',
      total: json['total'] ?? listaVoos.length,
      voos: listaVoos,
    );
  }
}

class VooService {

  static const String _baseUrl = 'http://127.0.0.1:5001/api';

 
  Future<ResultadoVoos> buscarVoos({
    required String aeroporto,
    required String tipo,
  }) async {
    final uri = Uri.parse(
      '$_baseUrl/voos?aeroporto=$aeroporto&tipo=$tipo',
    );

    final resposta = await http
        .get(uri)
        .timeout(const Duration(seconds: 20));

    if (resposta.statusCode == 200) {
      final Map<String, dynamic> dados = jsonDecode(
        utf8.decode(resposta.bodyBytes),
      );
      return ResultadoVoos.fromJson(dados);
    }

    try {
      final Map<String, dynamic> erroJson = jsonDecode(
        utf8.decode(resposta.bodyBytes),
      );
      throw Exception(erroJson['erro'] ?? 'Erro ao buscar voos.');
    } catch (_) {
      throw Exception(
        'Erro ao buscar voos (status ${resposta.statusCode}).',
      );
    }
  }
}
