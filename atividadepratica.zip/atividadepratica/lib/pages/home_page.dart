import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/voo_provider.dart';
import '../services/voo_service.dart';
import 'detalhes_page.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final TextEditingController _aeroportoController = TextEditingController(
    text: 'SBGR',
  );

  @override
  void initState() {
    super.initState();
    // Busca os voos assim que a tela abre.
    WidgetsBinding.instance.addPostFrameCallback((_) {
      context.read<VooProvider>().buscarVoos();
    });
  }

  @override
  void dispose() {
    _aeroportoController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final provider = context.watch<VooProvider>();

    return Scaffold(
      appBar: AppBar(title: const Text('Painel de Voos')),
      body: Column(
        children: [
          _buildFiltros(provider),
          Expanded(child: _buildConteudo(provider)),
        ],
      ),
    );
  }

  // Campo de aeroporto (ICAO) + seletor de tipo de voo.
  Widget _buildFiltros(VooProvider provider) {
    return Padding(
      padding: const EdgeInsets.all(12),
      child: Column(
        children: [
          Row(
            children: [
              Expanded(
                child: TextField(
                  controller: _aeroportoController,
                  textCapitalization: TextCapitalization.characters,
                  maxLength: 4,
                  decoration: const InputDecoration(
                    labelText: 'Código ICAO (ex.: SBGR)',
                    border: OutlineInputBorder(),
                    counterText: '',
                  ),
                  onSubmitted: (valor) {
                    if (valor.trim().length == 4) {
                      provider.mudarAeroporto(valor);
                    }
                  },
                ),
              ),
              const SizedBox(width: 8),
              ElevatedButton(
                onPressed: () {
                  final valor = _aeroportoController.text.trim();
                  if (valor.length == 4) {
                    provider.mudarAeroporto(valor);
                  } else {
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(
                        content: Text('Digite um código ICAO com 4 letras.'),
                      ),
                    );
                  }
                },
                child: const Text('Buscar'),
              ),
            ],
          ),
          const SizedBox(height: 8),
          SegmentedButton<String>(
            segments: const [
              ButtonSegment(value: 'todos', label: Text('Todos')),
              ButtonSegment(value: 'chegadas', label: Text('Chegadas')),
              ButtonSegment(value: 'partidas', label: Text('Partidas')),
            ],
            selected: {provider.tipo},
            onSelectionChanged: (novoValor) {
              provider.mudarTipo(novoValor.first);
            },
          ),
        ],
      ),
    );
  }

  // Loading / erro / lista de voos.
  Widget _buildConteudo(VooProvider provider) {
    if (provider.carregando) {
      return const Center(child: CircularProgressIndicator());
    }

    if (provider.erro != null) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Icon(Icons.error_outline, size: 48, color: Colors.red),
              const SizedBox(height: 12),
              Text(
                provider.erro!,
                textAlign: TextAlign.center,
                style: const TextStyle(fontSize: 16),
              ),
              const SizedBox(height: 12),
              ElevatedButton(
                onPressed: provider.buscarVoos,
                child: const Text('Tentar novamente'),
              ),
            ],
          ),
        ),
      );
    }

    if (provider.voos.isEmpty) {
      return const Center(child: Text('Nenhum voo encontrado.'));
    }

    return RefreshIndicator(
      onRefresh: provider.buscarVoos,
      child: ListView.separated(
        padding: const EdgeInsets.symmetric(vertical: 8),
        itemCount: provider.voos.length,
        separatorBuilder: (_, __) => const Divider(height: 1),
        itemBuilder: (context, index) {
          final voo = provider.voos[index];
          return _VooTile(voo: voo);
        },
      ),
    );
  }
}

class _VooTile extends StatelessWidget {
  final Voo voo;
  const _VooTile({required this.voo});

  IconData _iconePorCategoria() {
    switch (voo.categoria) {
      case 'chegadas':
        return Icons.flight_land;
      case 'partidas':
        return Icons.flight_takeoff;
      default:
        return Icons.flight;
    }
  }

  @override
  Widget build(BuildContext context) {
    return ListTile(
      leading: Icon(_iconePorCategoria()),
      title: Text(
        voo.identificacao,
        style: const TextStyle(fontWeight: FontWeight.bold),
      ),
      subtitle: Text(voo.local ?? 'Local não informado'),
      trailing: Text(voo.partida ?? voo.chegada ?? ''),
      onTap: () {
        Navigator.push(
          context,
          MaterialPageRoute(builder: (_) => DetalhesPage(voo: voo)),
        );
      },
    );
  }
}
