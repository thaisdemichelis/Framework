import 'package:flutter/material.dart';
import '../services/voo_service.dart';

class DetalhesPage extends StatelessWidget {
  final Voo voo;

  const DetalhesPage({super.key, required this.voo});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(voo.identificacao)),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Card(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    voo.identificacao,
                    style: const TextStyle(
                      fontSize: 24,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    'Categoria: ${voo.categoria}',
                    style: TextStyle(color: Colors.grey[700]),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 16),
          _linhaDetalhe(Icons.place, 'Local (origem/destino)', voo.local),
          _linhaDetalhe(
            Icons.airplanemode_active,
            'Tipo de aeronave',
            voo.tipoAeronave,
          ),
          _linhaDetalhe(Icons.flight_takeoff, 'Horário de partida', voo.partida),
          _linhaDetalhe(Icons.flight_land, 'Horário de chegada', voo.chegada),
        ],
      ),
    );
  }

  Widget _linhaDetalhe(IconData icone, String titulo, String? valor) {
    return Card(
      margin: const EdgeInsets.only(bottom: 8),
      child: ListTile(
        leading: Icon(icone),
        title: Text(titulo),
        subtitle: Text(valor?.isNotEmpty == true ? valor! : 'Não informado'),
      ),
    );
  }
}
