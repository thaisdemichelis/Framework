package com.example.atividadepratica

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
